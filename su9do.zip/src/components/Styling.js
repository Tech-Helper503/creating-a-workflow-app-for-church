import Stylesheet from 'react-native-web';

const styles = new Stylesheet.create({

})